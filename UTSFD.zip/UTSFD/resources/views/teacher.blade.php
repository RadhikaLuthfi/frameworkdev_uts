@extends('templates.default')

@section('content')
    <h1>Teacher</h1>
@endsection
