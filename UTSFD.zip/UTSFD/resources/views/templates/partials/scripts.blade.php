<script src="./dist/libs/apexcharts/dist/apexcharts.min.js"></script>
<!-- Tabler Core -->
<script src="./dist/js/tabler.min.js"></script>
<script src="./dist/js/demo.min.js"></script>
