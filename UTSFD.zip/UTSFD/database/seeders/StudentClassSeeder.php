<?php

namespace Database\Seeders;

use App\Models\StudentClass;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use PhpParser\Builder\Class_;

class StudentClassSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $classes = [
            [
                'name' => 'D3 TI 1',
                'slug' => 'd3-ti-1',
            ],
            [
                'name' => 'D3 TI 2',
                'slug' => 'd3-ti-2',
            ],
            [
                'name' => 'D3 TI 3',
                'slug' => 'd3-ti-3',
            ],
        ];

        foreach ($classes as $studentClass) {
            $class = new StudentClass();

            $class->name = $studentClass['name'];
            $class->slug = $studentClass['slug'];

            $class->save();
        }
    }
}
